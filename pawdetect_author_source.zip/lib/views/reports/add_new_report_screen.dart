import 'package:flutter/material.dart';
import 'package:pawdetect/l10n/app_localizations.dart';
import 'package:pawdetect/styles/app_colors.dart';
import 'package:pawdetect/views/shared/custom_appbar.dart';
import 'package:provider/provider.dart';
import 'package:pawdetect/viewmodels/report/add_report_viewmodel.dart';
import 'package:pawdetect/views/reports/widgets/add_new_report/add_new_report_form.dart';

class AddNewReportScreen extends StatelessWidget {
  const AddNewReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context)!; // localized strings

    return ChangeNotifierProvider(
      create: (_) => AddReportViewModel(),
      child: Scaffold(
        backgroundColor: AppColors.white,
        appBar: CustomAppBar(title: loc.report_add_new),
        body: const SafeArea(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: SingleChildScrollView(child: AddNewReportForm()),
          ),
        ),
      ),
    );
  }
}
